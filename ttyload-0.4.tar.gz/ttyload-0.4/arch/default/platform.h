/* This file contains default platform settings */

/* do we have ascftime()? */
#define	HAVE_ASCFTIME
